"""
Generate future sales forecasts using the trained best model.
Performs iterative (recursive) forecasting since lag/rolling features
depend on previously predicted values.
"""

import pandas as pd
import numpy as np
import joblib
import os

from src.preprocessing import load_data, add_date_features

FEATURE_COLS = [
    "price", "promotion", "holiday",
    "year", "month", "day", "weekday", "is_weekend", "weekofyear",
    "sales_lag_1", "sales_lag_7", "sales_lag_14", "sales_lag_30",
    "sales_roll_mean_7", "sales_roll_mean_14", "sales_roll_mean_30",
    "sales_roll_std_7", "sales_roll_std_14", "sales_roll_std_30",
]


def forecast_future(n_days=30, model_path="outputs/best_model.pkl", data_path="data/sales_data.csv"):
    model = joblib.load(model_path)
    df = load_data(data_path)

    history = df[["date", "sales", "price", "promotion", "holiday"]].copy()
    last_price = history["price"].iloc[-1]

    future_dates = pd.date_range(
        start=history["date"].max() + pd.Timedelta(days=1), periods=n_days, freq="D"
    )

    predictions = []

    for date in future_dates:
        row = {
            "date": date,
            "price": last_price,
            "promotion": 0,
            "holiday": int(date.strftime("%m-%d") in ["01-01", "12-25", "07-04", "11-25", "12-31"]),
        }

        temp = pd.concat([history, pd.DataFrame([row])], ignore_index=True)
        temp = add_date_features(temp)

        for lag in (1, 7, 14, 30):
            temp[f"sales_lag_{lag}"] = temp["sales"].shift(lag)
        for w in (7, 14, 30):
            temp[f"sales_roll_mean_{w}"] = temp["sales"].shift(1).rolling(window=w).mean()
            temp[f"sales_roll_std_{w}"] = temp["sales"].shift(1).rolling(window=w).std()

        latest = temp.iloc[[-1]][FEATURE_COLS]
        pred = model.predict(latest)[0]
        pred = max(pred, 0)

        row["sales"] = pred
        history = pd.concat([history, pd.DataFrame([row])], ignore_index=True)
        predictions.append({"date": date, "predicted_sales": round(pred, 2)})

    result = pd.DataFrame(predictions)
    return result


if __name__ == "__main__":
    os.makedirs("outputs", exist_ok=True)
    forecast = forecast_future(n_days=30)
    forecast.to_csv("outputs/future_forecast.csv", index=False)
    print(forecast)
    print("\nSaved to outputs/future_forecast.csv")

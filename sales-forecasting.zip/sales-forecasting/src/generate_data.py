"""
Generates a synthetic daily sales dataset for the Sales Forecasting project.
Creates: data/sales_data.csv
"""

import numpy as np
import pandas as pd

np.random.seed(42)

START_DATE = "2021-01-01"
END_DATE = "2023-12-31"

dates = pd.date_range(start=START_DATE, end=END_DATE, freq="D")
n = len(dates)

# Base trend (slowly increasing sales over time)
trend = np.linspace(200, 400, n)

# Weekly seasonality (higher sales on weekends)
weekday = dates.dayofweek
weekly_seasonality = np.where(weekday >= 5, 60, 0)

# Yearly seasonality (peak around Nov-Dec for holiday season)
day_of_year = dates.dayofyear
yearly_seasonality = 50 * np.sin(2 * np.pi * (day_of_year - 80) / 365)

# Random noise
noise = np.random.normal(0, 20, n)

# Promotions (random ~10% of days)
promotion = np.random.choice([0, 1], size=n, p=[0.9, 0.1])
promo_effect = promotion * np.random.uniform(40, 100, n)

# Holiday flag (simple: Jan 1, Dec 25, Jul 4, Nov 25-ish)
holiday = dates.strftime("%m-%d").isin(["01-01", "12-25", "07-04", "11-25", "12-31"]).astype(int)
holiday_effect = holiday * np.random.uniform(80, 150, n)

# Price (slight random variation)
price = np.round(np.random.uniform(8, 12, n), 2)

# Final sales calculation
sales = trend + weekly_seasonality + yearly_seasonality + noise + promo_effect + holiday_effect
sales = np.maximum(sales, 0).round(0).astype(int)

df = pd.DataFrame({
    "date": dates,
    "store_id": 1,
    "product_id": "P001",
    "sales": sales,
    "price": price,
    "promotion": promotion,
    "holiday": holiday
})

df.to_csv("data/sales_data.csv", index=False)
print(f"Generated {len(df)} rows -> data/sales_data.csv")
print(df.head())

"""
Train and compare multiple forecasting models:
- Linear Regression
- Random Forest
- XGBoost (if available)

Saves comparison results to outputs/model_comparison.csv
and the best model to outputs/best_model.pkl
"""

import pandas as pd
import numpy as np
import joblib
import os

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor

from src.preprocessing import load_data, build_features, train_test_split_by_date
from src.evaluation import evaluate

try:
    from xgboost import XGBRegressor
    XGB_AVAILABLE = True
except ImportError:
    XGB_AVAILABLE = False


FEATURE_COLS = [
    "price", "promotion", "holiday",
    "year", "month", "day", "weekday", "is_weekend", "weekofyear",
    "sales_lag_1", "sales_lag_7", "sales_lag_14", "sales_lag_30",
    "sales_roll_mean_7", "sales_roll_mean_14", "sales_roll_mean_30",
    "sales_roll_std_7", "sales_roll_std_14", "sales_roll_std_30",
]
TARGET_COL = "sales"


def main():
    os.makedirs("outputs", exist_ok=True)

    df = load_data()
    df = build_features(df)

    # Last 60 days as test set
    split_date = df["date"].max() - pd.Timedelta(days=60)
    train, test = train_test_split_by_date(df, split_date)

    X_train, y_train = train[FEATURE_COLS], train[TARGET_COL]
    X_test, y_test = test[FEATURE_COLS], test[TARGET_COL]

    models = {
        "LinearRegression": LinearRegression(),
        "RandomForest": RandomForestRegressor(n_estimators=200, random_state=42),
    }
    if XGB_AVAILABLE:
        models["XGBoost"] = XGBRegressor(
            n_estimators=200, learning_rate=0.05, max_depth=4, random_state=42
        )

    results = []
    best_model_name, best_model, best_rmse = None, None, np.inf

    for name, model in models.items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        metrics = evaluate(y_test, preds, model_name=name)
        results.append(metrics)
        print(metrics)

        if metrics["RMSE"] < best_rmse:
            best_rmse = metrics["RMSE"]
            best_model_name = name
            best_model = model

    results_df = pd.DataFrame(results)
    results_df.to_csv("outputs/model_comparison.csv", index=False)
    print("\nModel comparison saved to outputs/model_comparison.csv")
    print(results_df)

    joblib.dump(best_model, "outputs/best_model.pkl")
    print(f"\nBest model: {best_model_name} -> saved to outputs/best_model.pkl")

    # Save predictions for plotting
    test_out = test[["date", TARGET_COL]].copy()
    test_out["prediction"] = best_model.predict(X_test)
    test_out.to_csv("outputs/test_predictions.csv", index=False)


if __name__ == "__main__":
    main()

"""
Data preprocessing and feature engineering for Sales Forecasting.
"""

import pandas as pd
import numpy as np


def load_data(path="data/sales_data.csv"):
    df = pd.read_csv(path, parse_dates=["date"])
    df = df.sort_values("date").reset_index(drop=True)
    return df


def add_date_features(df):
    df = df.copy()
    df["year"] = df["date"].dt.year
    df["month"] = df["date"].dt.month
    df["day"] = df["date"].dt.day
    df["weekday"] = df["date"].dt.weekday
    df["is_weekend"] = (df["weekday"] >= 5).astype(int)
    df["weekofyear"] = df["date"].dt.isocalendar().week.astype(int)
    return df


def add_lag_features(df, lags=(1, 7, 14, 30)):
    df = df.copy()
    for lag in lags:
        df[f"sales_lag_{lag}"] = df["sales"].shift(lag)
    return df


def add_rolling_features(df, windows=(7, 14, 30)):
    df = df.copy()
    for w in windows:
        df[f"sales_roll_mean_{w}"] = df["sales"].shift(1).rolling(window=w).mean()
        df[f"sales_roll_std_{w}"] = df["sales"].shift(1).rolling(window=w).std()
    return df


def build_features(df):
    df = add_date_features(df)
    df = add_lag_features(df)
    df = add_rolling_features(df)
    df = df.dropna().reset_index(drop=True)
    return df


def train_test_split_by_date(df, split_date):
    train = df[df["date"] < split_date].reset_index(drop=True)
    test = df[df["date"] >= split_date].reset_index(drop=True)
    return train, test


if __name__ == "__main__":
    df = load_data()
    df = build_features(df)
    print(df.head())
    print(f"Shape after feature engineering: {df.shape}")
